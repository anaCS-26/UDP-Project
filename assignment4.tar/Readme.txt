Name: Asad Ansari
Student ID: 101216870

To submit: assignment4PPC.c, assignment4PPS.c, pokemon.c, pokemon.h, pokemon.csv, assignment4-Design Document.pdf

To compile and run the files, type "make" and run ./ps (server) and ./pc (client)
